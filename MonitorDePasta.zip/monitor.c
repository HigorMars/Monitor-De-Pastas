#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>

#define PASTA "./teste"
#define LOG "monitor.log"
#define INTERVALO 5  // segundos entre verificações

typedef struct {
    char nome[256];
    time_t mod;
} Arquivo;

int listar(Arquivo arqs[], int *n) {
    DIR *dir = opendir(PASTA);
    struct dirent *ent;
    struct stat st;
    char caminho[512];

    if (!dir) return 0;
    *n = 0;

    while ((ent = readdir(dir)) != NULL) {
        if (strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0)
            continue;

        snprintf(caminho, sizeof(caminho), "%s/%s", PASTA, ent->d_name);
        stat(caminho, &st);
        strcpy(arqs[*n].nome, ent->d_name);
        arqs[*n].mod = st.st_mtime;
        (*n)++;
    }
    closedir(dir);
    return 1;
}

void logar(const char *msg) {
    FILE *f = fopen(LOG, "a");
    time_t t = time(NULL);
    char *hora = ctime(&t);
    hora[strlen(hora)-1] = 0; // remove \n
    printf("[%s] %s\n", hora, msg);
    fprintf(f, "[%s] %s\n", hora, msg);
    fclose(f);
}

int main() {
    Arquivo antes[100], depois[100];
    int nAntes = 0, nDepois = 0;
    listar(antes, &nAntes);
    logar("Monitor iniciado.");

    while (1) {
        sleep(INTERVALO);
        listar(depois, &nDepois);

        // Novos arquivos e modificados
        for (int i = 0; i < nDepois; i++) {
            int achou = 0;
            for (int j = 0; j < nAntes; j++) {
                if (strcmp(depois[i].nome, antes[j].nome) == 0) {
                    achou = 1;
                    if (depois[i].mod != antes[j].mod) {
                        char msg[300];
                        sprintf(msg, "Arquivo modificado: %s", depois[i].nome);
                        logar(msg);
                    }
                    break;
                }
            }
            if (!achou) {
                char msg[300];
                sprintf(msg, "Novo arquivo: %s", depois[i].nome);
                logar(msg);
            }
        }

        // Arquivos removidos
        for (int i = 0; i < nAntes; i++) {
            int achou = 0;
            for (int j = 0; j < nDepois; j++) {
                if (strcmp(antes[i].nome, depois[j].nome) == 0)
                    achou = 1;
            }
            if (!achou) {
                char msg[300];
                sprintf(msg, "Arquivo removido: %s", antes[i].nome);
                logar(msg);
            }
        }

        memcpy(antes, depois, sizeof(depois));
        nAntes = nDepois;
    }

    return 0;
}
